// Instantiate form-authentication object
(function() {
  "use strict";
 
  var authenticationForm = Object.create(AuthenticationForm);
  authenticationForm.init();
}());